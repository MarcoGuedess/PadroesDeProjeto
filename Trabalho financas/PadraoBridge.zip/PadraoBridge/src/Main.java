package mercadinho.bridge; // <-- Adicionado para o Java achar as outras classes

public class Main {
    public static void main(String[] args) {
        Promocao semdesconto = new SemDesconto();

        // Exemplo de produto unitário (arroz) com 30% de desconto
        ProdutoUnitario arroz = new ProdutoUnitario(20.0f);
        arroz.setPromocao(semdesconto);
        System.out.println("Preço Arroz: " + arroz.calcularPrecoFinal()); // 14.0

        // Exemplo de produto pesável (carne) com 30% de desconto
        ProdutoPesavel carne = new ProdutoPesavel(50.0f); // 50 reais o kg
        carne.setPesoKg(2.0f); // 2kg
        carne.setPromocao(semdesconto);
        System.out.println("Preço Carne: " + carne.calcularPrecoFinal()); // 70.0 (100 - 30%)
    }
}